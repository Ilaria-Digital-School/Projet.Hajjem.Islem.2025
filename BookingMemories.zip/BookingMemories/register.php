<?php
include 'components/connect.php';
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel_db";

// Créer la connexion
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Inclure le fichier de connexion à la base de données

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les données du formulaire
   
    $email = $_POST['email'];
    $password = $_POST['password']; 

    // Valider les données (vous pouvez ajouter plus de validations ici)
    if (!empty($email) && !empty($password)) {
        // Hacher le mot de passe
        $salt = bin2hex(random_bytes(16)); // Génère un sel aléatoire

        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Préparer et exécuter la requête d'insertion
        $stmt = $conn->prepare("INSERT INTO users (email, password, salt) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $email, $hashed_password, $salt);

      
  
        if ($stmt->execute()) {
            echo "Inscription réussie!";
        } else {
            echo "Erreur : " . $stmt->error;
        }

        // Fermer la déclaration et la connexion
        $stmt->close();
        $conn->close();
    } else {
        echo "Veuillez remplir tous les champs.";
    }
}
?>
